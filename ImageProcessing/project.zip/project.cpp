#include <algorithm>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <iostream>
#include <string>
//#include <Windows.h>
#include <opencv2/opencv.hpp>
#include "opencv2/imgproc.hpp"
#include "opencv2/highgui.hpp"
#include <opencv2/core/utils/filesystem.hpp>
#include "libxl.h"

using namespace libxl;
using namespace cv;
using namespace std;


#include <vector>
#include <random>
#include <climits>
#include <algorithm>
#include <functional>

#include "ImageManipulation.cpp"
//#include "ImageEncryption.cpp"

using random_bytes_engine = std::independent_bits_engine<std::default_random_engine, CHAR_BIT, unsigned char>;


double getPSNR(const Mat& I1, const Mat& I2)
{
	Mat s1;
	absdiff(I1, I2, s1);       // |I1 - I2|
	s1.convertTo(s1, CV_32F);  // cannot make a square on 8 bits
	s1 = s1.mul(s1);           // |I1 - I2|^2
	Scalar s = sum(s1);         // sum elements per channel
	double sse = s.val[0] + s.val[1] + s.val[2]; // sum channels
	if (sse <= 1e-10) // for small values return zero
		return 0;
	else
	{
		double  mse = sse / (double)(I1.channels() * I1.total());
		double psnr = 10.0 * log10((255 * 255) / mse);
		return psnr;
	}
}

cv::Mat encryptBlock(cv::Mat block, int rows, int cols, int (&randim_variables)[4096]) {
	int counter = 0;
	cv::Mat* blocksXORed = new cv::Mat[(rows * cols)];
	for (int i = 0; i < rows; i++)
	{
		Vec3b* ptr = block.ptr<Vec3b>(i);
		for (int j = 0; j < cols; j++)
		{
			int random_index = ((rows) * i) + j;

			if (randim_variables[random_index]==0) {
				std::srand(std::time(nullptr)); // use current time as seed for random generator
				randim_variables[random_index] = (int)std::rand() % 255;
			}			
			

			cv::Mat resultLAB;
			Vec3b iv = 234;
			if (j != 0) {
				iv = ptr[j - 1];
			}
			Vec3b pixel = ptr[j];
			cv::bitwise_xor(pixel, iv, resultLAB);
			cv::bitwise_xor(resultLAB, randim_variables[random_index], resultLAB);
			block.ptr<Vec3b>(i)[j] = resultLAB;
			pixel = resultLAB;
		}
	}
	return block;
}

Scalar getMSSIM(const Mat& i1, const Mat& i2)
{
	const double C1 = 6.5025, C2 = 58.5225;
	/***************************** INITS **********************************/
	int d = CV_32F;
	Mat I1, I2;
	i1.convertTo(I1, d);           // cannot calculate on one byte large values
	i2.convertTo(I2, d);
	Mat I2_2 = I2.mul(I2);        // I2^2
	Mat I1_2 = I1.mul(I1);        // I1^2
	Mat I1_I2 = I1.mul(I2);        // I1 * I2
	/*************************** END INITS **********************************/
	Mat mu1, mu2;   // PRELIMINARY COMPUTING
	GaussianBlur(I1, mu1, Size(11, 11), 1.5);
	GaussianBlur(I2, mu2, Size(11, 11), 1.5);
	Mat mu1_2 = mu1.mul(mu1);
	Mat mu2_2 = mu2.mul(mu2);
	Mat mu1_mu2 = mu1.mul(mu2);
	Mat sigma1_2, sigma2_2, sigma12;
	GaussianBlur(I1_2, sigma1_2, Size(11, 11), 1.5);
	sigma1_2 -= mu1_2;
	GaussianBlur(I2_2, sigma2_2, Size(11, 11), 1.5);
	sigma2_2 -= mu2_2;
	GaussianBlur(I1_I2, sigma12, Size(11, 11), 1.5);
	sigma12 -= mu1_mu2;
	Mat t1, t2, t3;
	t1 = 2 * mu1_mu2 + C1;
	t2 = 2 * sigma12 + C2;
	t3 = t1.mul(t2);              // t3 = ((2*mu1_mu2 + C1).*(2*sigma12 + C2))
	t1 = mu1_2 + mu2_2 + C1;
	t2 = sigma1_2 + sigma2_2 + C2;
	t1 = t1.mul(t2);               // t1 =((mu1_2 + mu2_2 + C1).*(sigma1_2 + sigma2_2 + C2))
	Mat ssim_map;
	divide(t3, t1, ssim_map);      // ssim_map =  t3./t1;
	Scalar mssim = mean(ssim_map); // mssim = average of ssim map
	return mssim;
}
int main()
{
	string imageName[] = { "LenaRGB","BaboonRGB","PeppersRGB" };
	string imageType = ".bmp";
	const int image_size = 512;
	const int blockw = 64;
	const int blockh = 64;
	const int totalBlocks = (image_size / blockw) * (image_size / blockh);
	const int IV = 234;
	int results[3][totalBlocks][2]; // (MSB,Edge) x3

	for (int imageIndex = 0; imageIndex < (sizeof(imageName) / sizeof(imageName[0])); imageIndex++)
	{
		std::vector<cv::Mat> blocks;
		std::vector<cv::Mat> highBlocks(blocks);
		std::vector<cv::Mat> lowBlocks;
		std::vector<cv::Mat> edgeBlocks;
		std::vector<cv::Mat> msbBlocks;
		std::vector<cv::Mat> newCriteriaBlocks;
		string imagePath = "C:/Users/issa_/source/repos/PPU/PPU/images/bmp/" + imageName[imageIndex] + imageType;
		//Mat image = cv::imread(imagePath, IMREAD_UNCHANGED);
		ImageManipulation image(512, 64, 64, cv::imread(imagePath, IMREAD_UNCHANGED), imageName[imageIndex], imageName[imageIndex]);
		ImageManipulation originalImage = image;
		// Divide iamge into blocks
		int divideStatus = image.divideImage(blocks);
		highBlocks= blocks;
		lowBlocks = blocks;
		edgeBlocks = blocks;
		msbBlocks = blocks;
		newCriteriaBlocks = blocks;
		image.getLaplacian();
		// debug: save blocks
		cv::utils::fs::createDirectory(image.FolderName);
		// loop through all the blocks
		int msb_sum = 0;
		int edge_sum = 0;
		int msb_average;
		int new_msb_average=0;
		int edge_average;
		for (int j = 0; j < blocks.size(); j++)
		{
			std::string blockId = std::to_string(j);
			//ImageManipulation block(64, 8, 8, blocks[j], image.FolderName, image.ImageName + "_Block_" + blockId);
			ImageManipulation block(64, 8, 8, blocks[j]);
			// Get MSB count for each block
			int msb = block.getMSB();
			// Get the edge count for each block
			//int laplacian = block.getLaplacian(imageName[imageIndex], blockId);
			int laplacian = block.getLaplacian();
			// write the block to the folder
			//std::string blockImgName = imageName[imageIndex] + "/block#" + blockId + "_MSB_" + std::to_string(msb) + ".bmp";
			//imwrite(blockImgName, blocks[j]);
			results[imageIndex][j][0] = msb;
			results[imageIndex][j][1] = laplacian;
			msb_sum += msb;
			edge_sum += laplacian;
		}
		edge_average = edge_sum / totalBlocks;
		msb_average = msb_sum / totalBlocks;
		for (int j = 0; j < blocks.size(); j++)
		{
			new_msb_average += (sqrt(results[imageIndex][j][0]) + edge_average);
		}
		new_msb_average = new_msb_average / totalBlocks;
		int random_variables[4096] = {};

		for (int j = 0; j < blocks.size(); j++)
		{
			std::string blockId = std::to_string(j);
			ImageManipulation block(64, 8, 8, blocks[j], image.FolderName, image.ImageName + "_Block_" + blockId);
			
			if (
				results[imageIndex][j][0] >= msb_average && results[imageIndex][j][1] >= edge_average				
				) {
				//encrypt the high block
				cv::Mat blockEncrypted = encryptBlock(block.Image.clone(), block.Rows, block.Cols, random_variables);
				highBlocks[j] = blockEncrypted;
			}
			
			if (results[imageIndex][j][0] <= msb_average && results[imageIndex][j][1] <= edge_average) {
				//encrypt the low block				
				cv::Mat blockEncrypted = encryptBlock(block.Image.clone(), block.Rows, block.Cols, random_variables);
				lowBlocks[j] = blockEncrypted;
			}
			
			if (results[imageIndex][j][0] >= msb_average ) {
				//encrypt the msb block				
				cv::Mat blockEncrypted = encryptBlock(block.Image.clone(), block.Rows, block.Cols, random_variables);
				msbBlocks[j] = blockEncrypted;
			}
			
			if (results[imageIndex][j][1] >= edge_average) {
				//encrypt the ege block				
				cv::Mat blockEncrypted = encryptBlock(block.Image.clone(), block.Rows, block.Cols, random_variables);
				edgeBlocks[j] = blockEncrypted;
			}
			
			
			//if ( (sqrt( results[imageIndex][j][0])+ edge_average) >= new_msb_average) {
				if(j==0){
				//encrypt the ege block				
				cv::Mat blockEncrypted = encryptBlock(block.Image.clone(), block.Rows, block.Cols, random_variables);
				newCriteriaBlocks[j] = blockEncrypted;
			}
			
			
			
		}
		cv::Mat highEncryptedImage = image.gatherImage(highBlocks);		
		cv::Mat lowEncryptedImage = image.gatherImage(lowBlocks);
		cv::Mat msbEncryptedImage = image.gatherImage(msbBlocks);
		cv::Mat edgeEncryptedImage = image.gatherImage(edgeBlocks);
		cv::Mat newCriteriaEncryptedImage = image.gatherImage(newCriteriaBlocks);
		

		double highPsnr = getPSNR(originalImage.Image, highEncryptedImage);		
		Scalar highScalar = getMSSIM(originalImage.Image, highEncryptedImage);
		double lowPsnr = getPSNR(originalImage.Image, lowEncryptedImage);
		Scalar lowScalar = getMSSIM(originalImage.Image, lowEncryptedImage);
		double msbPsnr = getPSNR(originalImage.Image, msbEncryptedImage);
		Scalar msbScalar = getMSSIM(originalImage.Image, msbEncryptedImage);
		double edgePsnr = getPSNR(originalImage.Image, edgeEncryptedImage);
		Scalar edgeScalar = getMSSIM(originalImage.Image, edgeEncryptedImage);
		double newCriteriaPsnr = getPSNR(originalImage.Image, newCriteriaEncryptedImage);
		Scalar newCriteriaScalar = getMSSIM(originalImage.Image, newCriteriaEncryptedImage);
		

		std::string originalImgName = originalImage.FolderName + "/original.bmp";
		std::string highEncryImgName = originalImage.FolderName + "/highEncry_PSNR_"
			+ std::to_string(highPsnr)+"_RGB_"+ std::to_string(highScalar.val[2] * 100) +"_" + std::to_string(highScalar.val[1] * 100) + "_" + std::to_string(highScalar.val[0] * 100) + + "_" + ".bmp";
		std::string lowEncryImgName = originalImage.FolderName + "/lowEncry_PSNR_"
			+ std::to_string(lowPsnr) + "_RGB_" + std::to_string(lowScalar.val[2] * 100) + "_" 
			+ std::to_string(lowScalar.val[1] * 100) + "_" + std::to_string(lowScalar.val[0] * 100) + +"_" + ".bmp";
		std::string msbEncryImgName = originalImage.FolderName + "/msbEncry_PSNR_"
			+ std::to_string(msbPsnr) + "_RGB_" + std::to_string(msbScalar.val[2] * 100) + "_"
			+ std::to_string(msbScalar.val[1] * 100) + "_" + std::to_string(msbScalar.val[0] * 100) + +"_" + ".bmp";
		std::string edgeEncryImgName = originalImage.FolderName + "/edgeEncry_PSNR_"
			+ std::to_string(edgePsnr) + "_RGB_" + std::to_string(edgeScalar.val[2] * 100) + "_"
			+ std::to_string(edgeScalar.val[1] * 100) + "_" + std::to_string(edgeScalar.val[0] * 100) + +"_" + ".bmp";
		std::string newCriteriaEncryImgName = originalImage.FolderName + "/newCriteriaEncry_PSNR_"
			+ std::to_string(newCriteriaPsnr) + "_RGB_" + std::to_string(newCriteriaScalar.val[2] * 100) + "_"
			+ std::to_string(newCriteriaScalar.val[1] * 100) + "_" + std::to_string(newCriteriaScalar.val[0] * 100) + +"_" + ".bmp";

		imwrite(originalImgName, originalImage.Image);
		imwrite(highEncryImgName, highEncryptedImage);
		
		imwrite(lowEncryImgName, lowEncryptedImage);		
		imwrite(msbEncryImgName, msbEncryptedImage);
		imwrite(edgeEncryImgName, edgeEncryptedImage);
		imwrite(newCriteriaEncryImgName, newCriteriaEncryptedImage);
		
	}

	// export results to excel sheet
	Book* book = xlCreateBook(); // xlCreateXMLBook() for xlsx
	if (book)
	{
		Sheet* sheet = book->addSheet(L"Sheet1");
		if (sheet)
		{
			sheet->writeStr(2, 1, L"Images MSB + Edge Count" );
			int seperation = 0;
			int imageIndex = 0;
			for (int imageIndex = 0; imageIndex < 3; imageIndex++)
			{
				sheet->writeStr(2 + seperation, 1, L"Images MSB + Edge Count");
				sheet->writeStr(3 + seperation, 1, L"B#");
				sheet->writeStr(3 + seperation, 2, L"MSB");
				sheet->writeStr(3 + seperation, 3, L"Edge");
				for (int k = 0; k < totalBlocks; k++) {
					sheet->writeNum(4 + k + seperation, 1, k);
					sheet->writeNum(4 + k + seperation, 2, results[imageIndex][k][0]);
					sheet->writeNum(4 + k + seperation, 3, results[imageIndex][k][1]);
				}
				seperation += totalBlocks + 4;
			}
		}
		book->save(L"example.xls");
		book->release();
	}
	return 0;

}
